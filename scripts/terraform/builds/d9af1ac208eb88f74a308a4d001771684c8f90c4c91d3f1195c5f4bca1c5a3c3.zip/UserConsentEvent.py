from typing import Optional


class UserConsentEvent:
    action: str
    consentType: str
    docVersion: str
    entityType: str
    member: str
    pk: str
    realm: str
    sk: str
    timeOfAction: str

    SHOWN: Optional[str]

    def __init__(
        self, action, consentType, docVersion, entityType, member, pk, realm, sk, timeOfAction
    ):
        self.action = action
        self.consentType = consentType
        self.docVersion = docVersion
        self.entityType = entityType
        self.member = member
        self.pk = pk
        self.realm = realm
        self.sk = sk
        self.timeOfAction = timeOfAction

        self.SHOWN = timeOfAction if action == "SHOWN" else None
        self.SKIPPED = timeOfAction if action == "SKIPPED" else None
        self.ACCEPTED = timeOfAction if action == "ACCEPTED" else None
        self.REVOKED = timeOfAction if action == "REVOKED" else None

    def to_dict(self):
        return {
            "action": self.action,
            "consentType": self.consentType,
            "docVersion": self.docVersion,
            "entityType": self.entityType,
            "member": self.member,
            "pk": self.pk,
            "realm": self.realm,
            "sk": self.sk,
            "timeOfAction": self.timeOfAction,
            "SHOWN": self.SHOWN,
            "SKIPPED": self.SKIPPED,
            "ACCEPTED": self.ACCEPTED,
            "REVOKED": self.REVOKED,
        }

    @staticmethod
    def from_item(item):
        return UserConsentEvent(
            action=item["action"],
            consentType=item["consentType"],
            docVersion=item["docVersion"],
            entityType=item["entityType"],
            member=item["member"],
            pk=item["pk"],
            realm=item["realm"],
            sk=item["sk"],
            timeOfAction=item["timeOfAction"],
        )
