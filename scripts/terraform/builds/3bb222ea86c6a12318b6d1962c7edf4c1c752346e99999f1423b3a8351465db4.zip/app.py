import json
import os
from datetime import datetime
from typing import TypedDict

import boto3


class UserConsentEvent:
    entity_type = "UserConsentEvent"
    action: str
    consent_type_identifier: str
    document_version_effective_start_date: str
    user_id: str
    pk: str
    realm_identifier: str
    sk: str
    time_of_action: str

    def __init__(
        self,
        action,
        consent_type_identifier,
        document_version_effective_start_date,
        user_id,
        realm_identifier,
        time_of_action,
        pk=None,
        sk=None,
    ):
        self.action = action
        self.consent_type_identifier = consent_type_identifier
        self.document_version_effective_start_date = document_version_effective_start_date
        self.user_id = user_id
        self.pk = pk
        self.realm_identifier = realm_identifier
        self.sk = sk
        self.time_of_action = time_of_action

    def to_item(self):
        return {
            "Action": self.action,
            "ConsentTypeIdentifier": self.consent_type_identifier,
            "DocumentVersionEffectiveStartDate": self.document_version_effective_start_date,
            "EntityType": self.entity_type,
            "UserId": self.user_id,
            "pk": self.pk if self.pk is not None else self.generate_pk_from_other_properties(),
            "RealmIdentifier": self.realm_identifier,
            "sk": self.sk if self.sk is not None else self.generate_sk_from_other_properties(),
            "TimeOfAction": self.time_of_action,
        }

    def generate_pk_from_other_properties(self):
        return "REALM#{realm}#USER#{user}".format(realm=self.realm_identifier, user=self.user_id)

    def generate_sk_from_other_properties(self):
        return "CT#{consent_type}#DV#{consent_document_effective_start_date}#TS#{timestamp}".format(
            consent_type=self.consent_type_identifier,
            consent_document_effective_start_date=self.document_version_effective_start_date,
            timestamp=self.time_of_action,
        )


localstack_hostname = os.environ.get("LOCALSTACK_HOSTNAME")
localstack_endpoint = (
    "http://" + localstack_hostname + ":4566" if localstack_hostname is not None else None
)
dynamodb = boto3.resource(
    "dynamodb",
    endpoint_url=localstack_endpoint,
)
table_name = os.environ.get("DYNAMODB_TABLE_NAME")
table = dynamodb.Table(table_name)


class CreateUserConsentEventPathParams(TypedDict):
    realm_identifier: str
    user_id: str
    consent_type_identifier: str
    consent_document_effective_start_date: str


class CreateUserConsentEventRequestBody(TypedDict):
    action: str


def parse_path_parameters(path_parameters: dict) -> CreateUserConsentEventPathParams:
    realm_identifier = path_parameters["realmIdentifier"]
    user = path_parameters["user"]
    consent_type_identifier = path_parameters["consentTypeIdentifier"]
    consent_document_effective_start_date = path_parameters["consentDocumentEffectiveStartDate"]

    result: CreateUserConsentEventPathParams = {
        "realm_identifier": realm_identifier,
        "user_id": user,
        "consent_type_identifier": consent_type_identifier,
        "consent_document_effective_start_date": consent_document_effective_start_date,
    }

    return result


def parse_body(body: str) -> CreateUserConsentEventRequestBody:
    body_json = json.loads(body)

    result: CreateUserConsentEventRequestBody = {
        "action": body_json["action"],
    }

    return result


def lambda_handler(event, _context):
    try:
        path_parameters: CreateUserConsentEventPathParams = parse_path_parameters(
            event["pathParameters"]
        )
        body: CreateUserConsentEventRequestBody = parse_body(event["body"])

        uce = UserConsentEvent(
            action=body["action"],
            consent_type_identifier=path_parameters["consent_type_identifier"],
            document_version_effective_start_date=path_parameters[
                "consent_document_effective_start_date"
            ],
            user_id=path_parameters["user_id"],
            realm_identifier=path_parameters["realm_identifier"],
            time_of_action=datetime.now().isoformat(),
        )

        item = uce.to_item()
        table.put_item(Item=item)

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": "{}",
        }
    except Exception:
        return {"statusCode": 500, "body": "{}"}
